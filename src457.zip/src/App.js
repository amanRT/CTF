import React from 'react';
// import './App.css'; // Import your CSS file
import HomePage from './HomePage/Homepage';

function App() {
  return (
    
      <HomePage />
    
  );
}

export default App;
