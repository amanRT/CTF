import React from 'react';

function Logo() {
  return (
    <div className='logo' style={{ margin: '10px' }}>
      <img src="https://cdn.pixabay.com/photo/2017/03/16/21/18/logo-2150297_640.png" alt="loading" height='100px' />
      <div id="logo-name">
        <span>CTF</span>
        <span>A CYBER HACKATON</span>
      </div>
    </div>
  );
}

export default Logo;
