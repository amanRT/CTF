import React from 'react'

export default function NavBar() {
    return (
        <nav>
            <ul id='navbar-items' className=''>
                <li>Home</li>
                <li>Score Board</li>
                <li>Graph</li>
                <li>Challenges</li>
            </ul>

        </nav>
    )
}
