import React from 'react';

function Logo1() {
  return (
    <div className='logo1'>
      <img src="https://cdn.pixabay.com/photo/2017/03/16/21/18/logo-2150297_640.png" alt="loading"  style={{ height: '150px', width: '150px' }} />
      <div id="logo-name">
      </div>
    </div>
  );
}

export default Logo1;
